interface ColorfulFlashlight extends Flashlight{
    void setColor(String color);
    String getColor();
}