interface Flashlight {
    void turnOn();
    void turnOff();
	boolean isOn();
    boolean isOff();
}